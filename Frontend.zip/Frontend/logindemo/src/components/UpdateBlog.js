import React from 'react'

const UpdateBlog = () => {
  return (
    <div>
        <h1>This is edit</h1>
      
    </div>
  )
}

export default UpdateBlog
