import axios from 'axios'
import React, { useEffect, useState } from 'react'


const AssignPost = () => {
    const [userInfo,setUserInfo]=useState([])


    useEffect(()=>{
        LoadUser()
      },[])
    
      const LoadUser=async()=>{
    
        axios.get('http://localhost:2023/api/user/all')
        .then((response)=>{
          setUserInfo(response.data);
        })
        .catch((error)=>{
          console.error('Error fetching data:', error);
        });
      }

      const handleAssign = async (userId,postId) => {
        try {
          const postData = { userInfo };
    
          await axios.post(`http://localhost:2023/api/user/assignPost/${userId}/${postId}`, postData);


          console.log(postData)
    
          setUserInfo(prevUserInfo => {
            const updatedUsers = prevUserInfo.map(user => {
              if (user.id === userId) {
                return { ...user, post: postData }; 
              }
              return user;
            });
            return updatedUsers;
          });
    
          console.log("Post assigned successfully!");
        } catch (error) {
          console.error("Error assigning post:", error);
        }

      };
     


  return (
    <div>
    <div className='container'>
    <div className='py-4'>
    <table className="table border shadow">
<thead>
<tr>
  <th scope="col">#</th>
  <th scope="col">First Name</th>
  <th scope="col">Last Name</th>
  <th scope="col">Email</th>
</tr>
</thead>
<tbody class="table-group-divider">
{userInfo.map((item, index) => (
        <tr key={index}>
          <td>{index+1}</td>
          <td>{item.first_name}</td>
          <td>{item.last_name}</td>
          <td>{item.email}</td>
          <td>{item.post ? item.post.title : 'No Post Assigned'}</td>
          <td>
        
                    <button onClick={() => handleAssign(item.id)} className='btn btn-primary mx-2'>Assign Post to {index + 1}</button>

                  
          </td>
        </tr>
      ))}
</tbody>
</table>


    </div>
  
</div>
  

</div>
  )
}

export default AssignPost
