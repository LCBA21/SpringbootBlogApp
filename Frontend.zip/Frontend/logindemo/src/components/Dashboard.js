import axios from 'axios';
import React, { useEffect, useState, } from 'react'
import { Link } from 'react-router-dom';

const Dashboard = () => {
  const[userData,setUserData]=useState([]);

  useEffect(()=>{
    LoadUser()

  },[])

  const LoadUser=async()=>{

    axios.get('http://localhost:2023/api/user/getAllPosts')
    .then((response)=>{
      setUserData(response.data);
    })
    .catch((error)=>{
      console.error('Error fetching data:', error);

    });
  }


  return (
    <div>
        <div className='container'>
        <div className='py-4'>
        <table className="table border shadow">
  <thead>
    <tr>
      <th scope="col">#</th>
      <th scope="col">Blog Title</th>
      <th scope="col">Blog Content</th>
    </tr>
  </thead>
  <tbody class="table-group-divider">
    {userData.map((item, index) => (
            <tr key={index}>
              <td>{index+1}</td>
              <td>{item.title}</td>
              <td>{item.content}</td>
              <td>
                <Link className='btn btn-primary mx-2' to={`/Blog`}>Add Post</Link>
              </td>
            </tr>
          ))}
  </tbody>
</table>


        </div>
      
    </div>
      

    </div>
  )
}

export default Dashboard
