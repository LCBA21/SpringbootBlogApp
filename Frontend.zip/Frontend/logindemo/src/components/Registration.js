import axios from 'axios';
import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';




const Registration = () => {

    const navigate = useNavigate(); 

  const [user, setUser] = useState({
    first_name: '',
    last_name: '',
    password: '',
    email: '',
  });

  const [confirmPassword,setConfirmPassword]=useState("")



  const { first_name, last_name, password, email } = user;

  const handleOnChange = (e) => {
    setUser({ ...user, [e.target.name]: e.target.value });
  };

  const handleConfirmPassword=(e)=>{
    setConfirmPassword( e.target.value );
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    if(first_name ===""){
        alert("First Name required")
    }else if(last_name ===""){
        alert("last_name required")
    }else if(password ===""){
        alert("Password required")
    }else if(confirmPassword ===""){
        alert("Cofirm Password required")
    }else if(email ===""){
        alert("Email required")
    }else if(password !==confirmPassword){
        alert("Password do not match ")
    }else{
        try {

            await axios.post("http://localhost:2023/api/user/save", user);
      
            setUser({
              first_name: '',
              last_name: '',
              password: '',
              email: '',
            });
            console.log(user)
      
            console.log("User registered successfully!");
          } catch (error) {
            console.error("Error registering the user:", error);
          }
          alert("Succesfully Registered")
        navigate('/Login');
    }
 
};

  return (


    <div  className='container'>
    <div className='row'>
      <div className='col-md-6 offset-md-3 border rounded p-4 mt-2 shadow'>
        <div className='mb-3'>
            <label htmlFor='Name' className='form-label'>
              Name
            </label>
         <input
          type="text"
          className='form-control'
          name="first_name"
          value={first_name}
          onChange={handleOnChange}
          placeholder="First Name"
        />
         </div>  
    

         <div className='mb-3'>
            <label htmlFor='Last Name' className='form-label'>
            Last Name
            </label>
        <input
          type="text"
          className='form-control'
          name="last_name"
          value={last_name}
          onChange={handleOnChange}
          placeholder="Last  Name"
        />
      </div>


      <div className='mb-3'>
            <label htmlFor='Password' className='form-label'>
              Password
            </label>
        <input
          type="password"
          className='form-control'
          name="password"
          value={password}
          onChange={handleOnChange}
          placeholder="Password"
        />
      </div>

      <div className='mb-3'>
            <label htmlFor='Password' className='form-label'>
              Password
            </label>
        <input
          type="password"
          className='form-control'
          name="confirm password"
          value={confirmPassword}
          onChange={handleConfirmPassword}
          placeholder="Confirm Password"
        />
      </div>


      <div className='mb-3'>
            <label htmlFor='Email' className='form-label'>
              Email
            </label>
        <input
          type="email"
          className='form-control'
          name="email"
          value={email}
          onChange={handleOnChange}
          placeholder="Email"
        />
      </div>

      <button className='btn btn-primary mx-2'  onClick={handleSubmit}  type="button">Register</button>
      <button className='btn btn-danger mx-2'>Cancel</button>
        </div>
    </div>
</div>

  );
};

export default Registration;

