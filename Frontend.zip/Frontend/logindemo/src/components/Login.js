import React, { useState,useEffect } from 'react'
import axios from 'axios'
import { useNavigate } from 'react-router-dom';


const Login = () => {

    const navigate = useNavigate(); 
    const [data,setData] = useState([]);
    const [user, setUser] = useState({
        firstName:"",
        username: "",
        password: "",
        email: "",
    });

    const { firstName, username, password,email } = user;
 
    const handleOnChange = (e) => {
        setUser({ ...user, [e.target.name]: e.target.value });
        
    }

    

    useEffect(() => {
        loadUser();
      }, []);

      const loadUser = async () => {
        try {
            const response = await axios.get('http://localhost:2023/api/user/all');
            setData(response.data);
        } catch (error) {
            console.error('Error loading users:', error);
        }
    };
    




    const validate=()=>{
     
        let passwordDb = data.find((pass)=> pass.password  === password);
        let usernameDb = data.find((pass)=> pass.username  === username);



        if (!usernameDb) {
            alert("Incorrect Username does not exist");
        } else if (passwordDb && passwordDb.password === password) {
            alert("Successfully Logged In");
            navigate('/dashboard');
        } else {
            alert("Incorrect Password");
        }
        

    }


  return (
    <div  className='container'>
    <div className='row'>
      <div className='col-md-6 offset-md-3 border rounded p-4 mt-2 shadow'>

      <div className='mb-3'>
            <label htmlFor='Username' className='form-label'>
              Username
            </label>
        <input
          type="text"
          className='form-control'
          name="username"
          value={username}
          onChange={handleOnChange}
          placeholder="Username"
        />
      </div>


      <div className='mb-3'>
            <label htmlFor='Password' className='form-label'>
              Password
            </label>
        <input
          type="password"
          className='form-control'
          name="password"
          value={password}
          onChange={handleOnChange}
          placeholder="Password"
        />
      </div>


    <button className='btn btn-primary mx-2' onClick={validate} >Login</button>
    <button className='btn btn-danger mx-2'>Cancel</button>

        </div>
      </div>
    </div>
  )

}

export default Login
