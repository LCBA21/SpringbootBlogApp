import axios from 'axios';
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';

const Blog = () => {
  const navigate = useNavigate();
  const [userInfo,setUserInfo]=useState([])


  const [blog, setBlog] = useState({
    title: '',
    content: '',
  });

  const { title, content } = blog;

  const handleOnChange = (e) => {
    setBlog({ ...blog, [e.target.name]: e.target.value });
  };

  const handleAssign = async (userId,postId) => {
    try {
      // Replace 'your_post_data_here' with the actual post data you want to assign
      const postData = { userInfo };

      await axios.post(`http://localhost:2023/api/user/assignPost/${userId}/${postId}`, postData);

      console.log(postData)

      // Update state based on previous state
      setUserInfo(prevUserInfo => {
        const updatedUsers = prevUserInfo.map(user => {
          if (user.id === userId) {
            return { ...user, post: postData }; // Assuming 'post' is the property to store the assigned post
          }
          return user;
        });
        return updatedUsers;
      });

      console.log("Post assigned successfully!");
    } catch (error) {
      console.error("Error assigning post:", error);
    }

  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (title === '') {
      alert('Title required');
    } else if (content === '') {
      alert('Content required');
    } else {
      try {
        await axios.post('http://localhost:2023/api/user/savePost', blog);
        setBlog({
          title: '',
          content: '',
        });
        console.log('Form submitted successfully!');
        navigate('/dashboard');
      } catch (error) {
        console.error('Error submitting the form:', error);
      }

      handleAssign();
    }
  };

  return (
    <div className='container'>
      <div className='row'>
        <div className='col-md-6 offset-md-3 border rounded p-4 mt-2 shadow'>
          <div className='mb-3'>
            <label htmlFor='Title' className='form-label'>
              Blog Title
            </label>
            <input
              type='text'
              className='form-control'
              name='title'
              value={title}
              onChange={handleOnChange}
              placeholder='Title'
            />
          </div>

          <div className='mb-3'>
            <label htmlFor='Content' className='form-label'>
              Blog Content
            </label>
            <input
              type='text'
              className='form-control'
              name='content'
              value={content}
              onChange={handleOnChange}
              placeholder='Content'
            />
          </div>

          <button className='btn btn-primary mx-2' onClick={handleSubmit} type='submit'>
            Post
          </button>
          <button className='btn btn-secondary mx-2'>Cancel</button>
        </div>
      </div>
    </div>
  );
};

export default Blog;
