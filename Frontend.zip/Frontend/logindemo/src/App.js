import { useEffect, useState } from 'react';
import './App.css';
import Login from './components/Login';
import Registration from './components/Registration';
import axios from 'axios';
import Dashboard from './components/Dashboard';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import Blog from './components/Blog';
import '../node_modules/bootstrap/dist/css/bootstrap.min.css'
import UpdateBlog from './components/UpdateBlog';
import Home from './components/Home';
import AssignPost from './components/AssignPost';


function App() {

  const [globalData,setGlobalData]=useState();



  useEffect(() => {
    loadUser();
  }, []);


  const loadUser= async()=>{
    axios.get('http://localhost:2023/api/user/all')
    .then((response) => {
      setGlobalData(response.data);
    })
}



  return (
    <div className="App">
    <Router>
        <Routes>
        <Route exact path="/" element={<Home />} />
        <Route exact path="/registration" element={<Registration />} />
        <Route exact path="/dashboard" element={<Dashboard />} />
        <Route exact path="/edit" element={<UpdateBlog />} />
        <Route exact path="/Login" element={<Login    />} />
        <Route exact path="/Blog" element={<Blog   />} />
        <Route exact path="/Assign" element={<AssignPost   />} />
        </Routes>
      </Router>

    </div>
  );
}

export default App;
