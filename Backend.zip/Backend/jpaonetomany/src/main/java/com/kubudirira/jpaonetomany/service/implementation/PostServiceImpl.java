package com.kubudirira.jpaonetomany.service.implementation;

import com.kubudirira.jpaonetomany.model.Post;
import com.kubudirira.jpaonetomany.model.User;
import com.kubudirira.jpaonetomany.repository.PostRepository;
import com.kubudirira.jpaonetomany.service.PostService;
import lombok.AllArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@AllArgsConstructor
@Service
public class PostServiceImpl implements PostService {

    @Autowired
    PostRepository post_repo;


    @Override
    public Post updatePost(Integer postId, Post post) {


        Post fetchedPost = post_repo.findById(postId).get();

        fetchedPost.setTitle(post.getTitle());
        fetchedPost.setContent(post.getContent());
        fetchedPost.setPublished_on(post.getPublished_on());

        post_repo.save(fetchedPost);

        return post;
    }

//    public User save(User user) {
//
//        userRepository.save(user);
//        return null;
//    }


    @Override
    public Post savePost(Post post) {

        post_repo.save(post);
        return null;
    }

//        public List<User> findAll() {
//      return (List<User>) userRepository.findAll();
//    }
    @Override
    public List<Post> findAll() {

        return (List<Post>) post_repo.findAll();
    }

    @Override
    public Post findById(Integer post_id) {
        return post_repo.findById(post_id).get();
    }
}
