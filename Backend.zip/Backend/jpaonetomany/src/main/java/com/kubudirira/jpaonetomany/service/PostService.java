package com.kubudirira.jpaonetomany.service;

import com.kubudirira.jpaonetomany.model.Post;
import com.kubudirira.jpaonetomany.model.User;

import java.util.List;

public interface PostService {

    Post updatePost(Integer postId, Post post);

    public Post savePost(Post post) ;

    public List<Post> findAll();
    Post findById(Integer post_id);



}
