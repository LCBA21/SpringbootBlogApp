package com.kubudirira.jpaonetomany;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JpaonetomanyApplication {

	public static void main(String[] args) {
		SpringApplication.run(JpaonetomanyApplication.class, args);
	}

}
